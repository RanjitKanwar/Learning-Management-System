<?php

    $server_name = "localhost";
    $user_name = "root";
    $password = "";
    $db_name = "learning_mgmt_system";
?>