<?php

    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }

    include_once('../config/db_connect.php');
    include_once('../common/file_upload_functions.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "<p>Connection failed: ".mysqli_connect_error()."</p>";
    }

    if(isset($_POST['create_content'])){
        if(isset($_FILES['content_video']))
        {
            $file_name = $_FILES['content_video']['name'];
            $file_tmp_name = $_FILES['content_video']['tmp_name'];
            $file_size = $_FILES['content_video']['size'];
            $file_error = $_FILES['content_video']['error'];
            $file_type = $_FILES['content_video']['type'];
            $file_destination = upload_content_video($file_name, $file_tmp_name, $file_size, $file_error, $file_type);
            
            if($file_destination == "error")
            {
                echo "<h3><font color=red>Error uploading file!</font></h3>";
                echo "<p>Cannot add content!</p>";
            }
            else
            {
                $content_name = $_POST['content_name'];
                if(isset($_POST['is_free']))
                    $is_free_content = $_POST['is_free'];
                else
                    $is_free_content = 0;
                $course_id = $_POST['course_id'];
                $content_theory = $_POST['theory_notes'];

                $sql = "INSERT INTO `course_content`(`content_name`, `content_video_material`, `is_content_available_for_free_access`, 
                        `associated_with_course`, `theory_notes`) 
                        VALUES ('$content_name', '$file_destination', '$is_free_content', '$course_id', '$content_theory')";
                $result = mysqli_query($connect, $sql);
                if($result)
                {
                    echo "<font color='green'><p>Content created successfully!</p></font>";
                }
                else
                {
                    echo "<font color='red'><p>Content creation failed!</p></font>";
                    echo "<p>Error: ".mysqli_error($connect)."</p>";
                }
            }
        }
    }

    function get_courses_of_teacher($teacher_id)
    {
        global $connect;
        $sql = "SELECT `course_name`, `course_id` FROM `courses` WHERE `created_by_teacher_id` = '$teacher_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            return $result;
        }
        else
        {
            echo "<p>Error: ".mysqli_error($connect)."</p>";
            return "error";
        }
    }

?>

<!DOCTYPE html>
<html>
    <head>
        <title>LMS - Content Creation</title>
        <link type="stylesheet" href="../styles/common_layout.css">
        <script src="../tinymce/tinymce.min.js"></script>
        <script type="text/javascript" src="../scripts/text_editor.js"></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="../styles/styles.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    </head>
    <body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Create Course Content</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back To Dashboard</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
    <div class="container">
        <form action="create_course_content.php" method="post" enctype="multipart/form-data">
            <label for="content_name" class="form-label">Content Name</label>
            <input type="text" class="form-control" name="content_name" id="content_name" required>
            <br/><br/>
            <label for="content_video" class="form-label">Course Video Material</label>
            <input type="file" class="form-control" name="content_video" id="content_video" required>
            <br/><br/>
            <label for="is_free" class="form-label">Can freely accessed?</label>
            <input type="checkbox"  name="is_free" id="is_free">
            <br/><br/>
            <label for="theory_notes" class="form-label">Theory Notes</label>
            <textarea rows = "5" cols = "60" name = "theory_notes" id="text-editor"></textarea>
            <br/><br/>
            <label for="course_id" class="form-label">Assocaite With Course</label>
            <select name="course_id" class="form-control">
            <?php

                $courses = get_courses_of_teacher($_SESSION['teacher_id']);
                for($i=0;$i<mysqli_num_rows($courses);$i++)
                {
                    $course = mysqli_fetch_assoc($courses);
                    echo "<option value=".$course['course_id']." name=".$course['course_id'].">".$course['course_name']."</option>";
                }
            ?>
            </select>
            <br/><br/>
            <input type="submit" class="form-control btn btn-primary" name="create_content" value="Add Content">
        </form> 
    </div>
    </body>
</html>