<?php

    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if($connect){
        if(isset($_POST['register']))
        {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $phone = $_POST['phone'];
            $dob = $_POST['dob'];
            $city = $_POST['city'];

            $sql = "INSERT INTO `student`(`student_name`, `student_email`, `student_password`, `student_phone`, `student_dob`, `student_city`) 
                    VALUES ('$name', '$email', '$password', '$phone', '$dob', '$city')";
            $result = mysqli_query($connect, $sql);
            if($result)
            {
                echo "<h2>Registration successful!</h2>";
                echo "<a href='signin.php'>Click here to sign in</a>";
            }
            else
            {
                echo "<script>alert('Registration failed!');</script>";
                echo "Failed to register: ".mysqli_error($connect);
            }
        }
    }

?>

<html>
<head>
    <title>LMS - Student Register</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
<header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Register as Student</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        
      </nav>
    </header>
    <br/><br/>
    <!--Student registration form-->
    <div class="container px-4">
    <p><a href="../common/index.php"><< Go Back</a></p>
    <form action="register.php" method="post">
        <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name" required>
        </div>
        <div class="mb-3">
        <label for="email" class="form-label">Email Address</label>
        <input type="email" name="email" class="form-control" placeholder="someone@example.com" required>
        </div>
        <div class="mb-3">
        <label for="email" class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
        <div class="mb-3">
        <label for="phone" class="form-label">Phone Number</label>
        <input type="number" name="phone" placeholder="9876543210" class="form-control" required>
        </div>
        <div class="mb-3">
        <label for="dob" class="form-label">Date of Birth</label>
        <input type="date" name="dob" placeholder="Date Of Birth" class="form-control" required>
        </div>
        <div class="mb-3">
        <label for="city" class="form-label">City</label>
        <input type="text" name="city" class="form-control" placeholder="Your City" required>
        </div>
        <input type="submit" name="register" class="form-control btn btn-primary" value="Register">
    </form>
    <p>Already have an account? <a href="signin.php">Sign in</a></p>
    </div>
    
</body>
</html>