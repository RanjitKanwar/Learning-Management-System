<?php

    session_start();
    
    if(!isset($_SESSION['student_id']))
    {
        header("Location: ../common/index.php");
    }

    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

    if(!isset($_GET['quiz_id']) && !isset($_GET['question_no']))
    {
        header("Location: browse_courses.php");
    }

    $quiz_id = $_GET['quiz_id'];
    if(!isset($question_number))
        $question_number = $_GET['question_no'];

    if(isset($_POST['fetch_ques']))
    {
        if(isset($_POST['question_id']))
        {
            $option_id = $_POST['option_id'];
            $question_number = $_POST['question_number'];
            $question_id = $_POST['question_id'];
            if(store_quiz_answer($question_id, $option_id))
            {
                echo "<script>alert('Answer Stored!');</script>";
                $question_number++;
            }
            else
            {
                echo "Error: ".mysqli_error($connect);
            }
        }
        else
        {
            echo "Please select an option!";
        }
    }

    function get_quiz_questions($quiz_id)
    {
        global $connect;
        $sql = "SELECT * FROM `quiz_question` WHERE `associated_quiz_id` = '$quiz_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                return $result;
            }
            else
            {
                echo "<h2>No Quiz Found!</h2>";
            }  
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

    function get_quiz_all_answer_option($question_id, $quiz_id)
    {
        global $connect;
        $sql = "SELECT * FROM `quiz_answer` WHERE `associated_with_question` = '$question_id' AND `associated_quiz_id` = '$quiz_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                return $result;
            }
            else
            {
                echo "<h2>No Quiz Found!</h2>";
            }  
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

    function store_quiz_answer($question_id, $answer_id)
    {
        global $connect;
        $student_id = $_SESSION['student_id'];
        $sql = "INSERT INTO `student_quiz_answers`(`student_id`, `question_given_id`, `answer_given_id`) VALUES ('$student_id', '$question_id', '$answer_id')";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            return true;
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

    function update_quiz_complete($quiz_id)
    {
        global $connect;
        $student_id = $_SESSION['student_id'];

        //get number_of_attempts from student_enrolled_quiz table
        $sql = "SELECT `number_of_attempts` FROM `student_enrolled_quiz` WHERE `student_id` = '$student_id' AND `content_quiz_id` = '$quiz_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                $row = mysqli_fetch_assoc($result);
                $number_of_attempts = $row['number_of_attempts'];
                $number_of_attempts++;
                $sql = "UPDATE `student_enrolled_quiz` SET `is_completed` = '1', `number_of_attempts` = '$number_of_attempts' WHERE `student_id` = '$student_id' AND `content_quiz_id` = '$quiz_id'";
                $result = mysqli_query($connect, $sql);
                if($result)
                {
                    return true;
                }
                else
                {
                    echo "Error: ".mysqli_error($connect);
                }
            }
            else
            {
                echo "Error: ".mysqli_error($connect);
            }
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

?>

<!DOCTYPE html>
<html>
    <head>
        <title>LMS - View Quiz</title>
        <link type="stylesheet" href="../styles/common_layout.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <link rel="stylesheet" href="../styles/styles.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Quiz</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back to Home</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
        <div class="h-100 d-flex align-items-center justify-content-center">
        <div class="p-2">
        <form action="student_quiz.php?quiz_id=<?php echo $quiz_id; ?>&question_no=0" method="POST">
        <table class="table">
            <tr>
                <th>Quiz Question</th>
            </tr>
            
            <tr>
                <td>
                    <?php
                        $quiz_completed = false;
                        $quiz_questions = get_quiz_questions($quiz_id);
                        $all_ques = array();
                        while($row = mysqli_fetch_assoc($quiz_questions))
                        {
                            $all_ques[] = $row;
                        }
                        if($question_number >= count($all_ques))
                        {
                            if(update_quiz_complete(($quiz_id)))
                            {
                                echo "<h3><span class='badge badge-secondary'>Quiz Completed!</span></h3>";
                                $question_number = count($all_ques) - 1;
                                $quiz_completed = true;
                            }
                            else
                            {
                                echo "Error: ".mysqli_error($connect);
                            }
                        }
                        else if($question_number <= 0)
                        {
                            $question_number = 0;
                        }
                        echo $all_ques[$question_number]['question_text'];
                        echo "<input type='hidden' name='question_id' value='".$all_ques[$question_number]['question_id']."'>";
                        $quiz_answers = get_quiz_all_answer_option($all_ques[$question_number]['question_id'], $quiz_id);
                        $all_answer_option = array();
                        $count = 0;
                        echo "<div class='container mb-5'>";
                        echo "<div class='row'>";
                        while($row = mysqli_fetch_assoc($quiz_answers))
                        {
                            $all_answer_option[] = $row;
                            echo "<div class='col-12'>";
                            echo "<input type='radio' name='option_id' id='one' value=".$row['answer_id']." required> ".$row['option_text'];
                            if($count % 2 == 1)
                            {
                                echo "<br>";
                            }
                            echo "</div>";
                        }
                        echo "<input type='hidden' name='question_number' value='".$question_number."'>";
                        echo "</div>";
                        echo "</div>";
                        
                    ?>
                </td>
            </tr>
            <tr>
                <?php
                    if($quiz_completed)
                    {
                        echo "<td><a href='browse_enrolled_courses.php' class='form-control btn btn-primary'>Go Back to Courses Page!</a></td>";
                    }
                    else
                    {
                        echo "<td><input type='submit' name='fetch_ques' value='Next Question' class='form-control btn btn-primary'></td>";
                    }
                ?>
            </tr>
            <tr>
                <td><a href="quit_quiz.php"><font color=red><i class="fa fa-sign-out">   Quit Quiz</a></i></font></td>
            </tr>
        </table>
        </form>
        </div>
        </div>
    </body>
</html>
