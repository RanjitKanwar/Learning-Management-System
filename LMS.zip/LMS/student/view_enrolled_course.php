<?php

    session_start();
    
    if(!isset($_SESSION['student_id']))
    {
        header("Location: ../common/index.php");
    }

    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

    if(!isset($_GET['course_id']))
    {
        header("Location: browse_courses.php");
    }

    $course_id = $_GET['course_id'];
    $teacher_id;

    function get_current_selected_course($course_id)
    {
        global $connect;
        global $teacher_id;
        $sql = "SELECT * FROM `courses` WHERE `course_id` = ".$course_id;
        $result_course = mysqli_query($connect, $sql);
        if(mysqli_num_rows($result_course) > 0)
        {
            $row = mysqli_fetch_assoc($result_course);
            echo "<div class='card' style='padding:7px'>";
            echo "<img src='".$row['course_image']."' alt='Course Image' class='card-top-img img-thumbnail'>";
            echo "<h3>".$row['course_name']."</h3>";
            echo "<p>".$row['course_desc']."</p>";
            echo "<p>Price: ".$row['course_price']."</p>";
            echo "<p>Discount Price: ".$row['course_discount_price']."</p>";
            echo "<p>Start Date: ".$row['course_start_date']."</p>";
            echo "<p>End Date: ".$row['course_end_date']."</p>";
            echo "<p>Content Watched Count: ".get_content_watched_count($course_id)."</p>";
            $teacher_id = $row['created_by_teacher_id'];
            echo "<p>Created by: ".get_teacher_name($row['created_by_teacher_id'])."</p>";
            echo "</div>";
        }
        else
        {
            echo "<p>Course not found!</p>";
        }
    } 
    
    function get_teacher_name($teacher_id)
    {
        global $connect;
        $sql = "SELECT `teacher_name` FROM `teacher` WHERE `teacher_id` = '$teacher_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            $row = mysqli_fetch_assoc($result);
            return $row['teacher_name'];
        }
        else
        {
            return "Error: ".mysqli_error($connect);
        }
    }

    function get_course_content($course_id)
    {
        global $connect;
        global $course_content_ids;
        $sql = "SELECT * FROM `course_content` WHERE `associated_with_course` = ".$course_id;
        $result = mysqli_query($connect, $sql);
        if(mysqli_num_rows($result) > 0)
        {
            echo "<div class='grid-container'>";
            for($i = 0; $i < mysqli_num_rows($result); $i++)
            {
                
                echo "<div class='card' style='padding:7px; margin-bottom:10px'>";
                $row = mysqli_fetch_assoc($result);
                $content_url = $row['content_video_material'];
                
                echo "<video width='320px' height='180px' controls>
                            <source src=$content_url type='video/mp4'>
                            <source src=$content_url type='video/mov'>
                        </video>";
                echo "<h3>".$row['content_name']."</h3>";
                echo "<p>".$row['theory_notes']."</p>";
                echo "<a href='view_enrolled_content.php?content_id=".$row['content_id']."&course_id=".$course_id."'>Watch Content</a>";
                echo "</div>";
            }
            echo "</div>";
        }
        else
        {
            echo "<p>No content available!</p>";
        }
    }

    function get_content_watched_count($course_id)
    {
        global $connect;
        $sql = "SELECT `course_content_watched_count` FROM `student_enrolled_course` WHERE `course_id` = ".$course_id." AND `student_id` = ".$_SESSION['student_id'];
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            $row = mysqli_fetch_assoc($result);
            return $row['course_content_watched_count'];
        }
        else
        {
            return "Error: ".mysqli_error($connect);
        }
        
    }

?>

<!DOCTYPE html>
<html>
    <head>
        <title>View Course</title>
        <link rel="stylesheet" href="../common/grid_layout.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="../styles/styles.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        
    </head>
    <body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>View Course</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back to Home</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
        <div class="container">
            <div class="content">
                <div class="right" style="width: 50%;float:left;">
                
                    <div class="content">
                        <?php get_current_selected_course($course_id); ?>
                    </div>
                </div>
                <div class="left" style="width: 40%;float:right; margin:10px">
                    <div class="content">
                        <?php 
                            get_course_content($course_id);
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>