<?php

    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if($connect){
        if(isset($_POST['register']))
        {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $phone = $_POST['phone'];
            $city = $_POST['city'];

            $sql = "INSERT INTO `teacher`(`teacher_name`, `teacher_email`, `teacher_password`, `teacher_phone`, `teacher_city`) 
                    VALUES ('$name', '$email', '$password', '$phone', '$city')";
            $result = mysqli_query($connect, $sql);
            if($result)
            {
                echo "<h2>Registration successful!</h2>";
                echo "<a href='signin.php'>Click here to sign in</a>";
            }
            else
            {
                echo "<script>alert('Registration failed!');</script>";
                echo "Failed to register: ".mysqli_error($connect);
            }
        }
    }

?>

<html>
<head>
    <title>LMS - Teacher Register</title>
    <link type="stylesheet" href="../styles/common_layout.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Register as Instructor</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        
      </nav>
    </header>
    <br/><br/>
    <div class="container px-4">
    <p><a href="../common/index.php"><< Go Back</a></p>
    <!--Student registration form-->
    <form action="register.php" method="post">
        <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" class="form-control" name="name" placeholder="Name" required>
        </div>
        <div class="mb-3">
        <label for="email" class="form-label">Email address</label>
        <input type="email" class="form-control" name="email" placeholder="Email Address" required>
        </div>
        <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" name="password" placeholder="Password" required>
        </div>
        <div class="mb-3">
        <label for="phone" class="form-label">Phone</label>
        <input type="number" class="form-control" name="phone" placeholder="Phone Number" required><br/>
        </div>
        <div class="mb-3">
        <label for="city" class="form-label">City</label>
        <input type="text" class="form-control" name="city" placeholder="Your City" required><br/>
        </div>
        <input type="submit" class="form-control btn btn-primary" name="register" value="Register">
    </form>
    <p>Already have an account? <a href="signin.php">Sign in</a></p>
    </div>
</body>
</html>