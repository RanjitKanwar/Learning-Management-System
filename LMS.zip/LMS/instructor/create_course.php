<?php
    
    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }

    include_once('../config/db_connect.php');
    include_once('../common/file_upload_functions.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if($connect){
        
    }

    if(isset($_POST['create_course']))
        {
            if(isset($_FILES['course_image']))
            {
                $file_name = $_FILES['course_image']['name'];
                $file_tmp_name = $_FILES['course_image']['tmp_name'];
                $file_size = $_FILES['course_image']['size'];
                $file_error = $_FILES['course_image']['error'];
                $file_type = $_FILES['course_image']['type'];
                
                $file_destination = upload_course_thumbnail($file_name, $file_tmp_name, $file_size, $file_error, $file_type);
                
                if($file_destination == "error")
                {
                    echo "<h3><font color=red>Error uploading file!</font></h3>";
                    echo "<p>Cannot create course!</p>";
                }
                else
                {
                    $course_name = $_POST['course_name'];
                    $course_description = $_POST['course_description'];
                    $course_price = $_POST['course_price'];
                    $course_disc_price = $_POST['course_disc_price'];
                    $course_start_date = $_POST['course_start_date'];
                    $course_end_date = $_POST['course_end_date'];
                    $course_teacher_id = $_SESSION['teacher_id'];

                    $sql = "INSERT INTO `courses`(`course_name`, `course_desc`, `course_image`, `course_price`, `course_discount_price`, `course_start_date`, `course_end_date`, `created_by_teacher_id`) 
                            VALUES ('$course_name', '$course_description', '$file_destination', '$course_price', '$course_disc_price', '$course_start_date', '$course_end_date', '$course_teacher_id')";
                    $result = mysqli_query($connect, $sql);
                    if($result)
                    {
                        echo "<font color='green'><p>Course created successfully!</p></font>";
                    }
                    else
                    {
                        echo "<font color='red'><p>Course creation failed!</p></font>";
                        echo "<p>Error: ".mysqli_error($connect)."</p>";
                    }
                }
            }

            
        }

?>

<!DOCTYPE html>
<html>
<head>
    
    <title>LMS - Create Course</title>
    <link type="stylesheet" href="../styles/common_layout.css">
    <script src="../tinymce/tinymce.min.js"></script>
    <script type="text/javascript" src="../scripts/text_editor.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Create Course</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back To Dashboard</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <br/>
    <div class='container'>
    <!--Add a form for create course-->
    <form action="create_course.php" method="post" enctype="multipart/form-data">
        <label for="course_name" class='form-label'>Course Name</label>
        <input type="text" class='form-control' name="course_name" id="course_name" required>
        <br/><br/>
        <label for="course_description" class='form-label'>Course Description</label>
        <textarea rows = "5" cols = "60" class='form-control' name = "course_description" id="text-editor"></textarea>
        <br/><br/>
        <label for="course_image" class='form-label'>Course Thumbnail</label>
        <input type="file" class='form-control' name="course_image" id="course_image" required>
        <br/><br/>
        <label for="course_price" class='form-label'>Course Price</label>
        <input type="number" class='form-control' name="course_price" id="course_price" required>
        <br/><br/>
        <label for="course_price" class='form-label'>Course Discounted Price</label>
        <input type="number" class='form-control' name="course_disc_price" id="course_disc_price" required>
        <br/><br/>
        <label for="course_start_date" class='form-label'>Course Start Date</label>
        <input type="date" class='form-control' name="course_start_date" id="course_start_date" required>
        <br/><br/>
        <label for="course_end_date" class='form-label'>Course End Date</label>
        <input type="date" class='form-control' name="course_end_date" id="course_end_date" required>
        <br/><br/>
        <input type="submit" class='form-control btn btn-primary' name="create_course" value="Create Course">
    </form>
    </div>
</body>
</html>

