<?php

    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }
    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

    if(!isset($_GET['quiz_id']) && !isset($_GET['content_id']))
    {
        header("Location: course_view.php");
    }

    $quiz_id = $_GET['quiz_id'];
    $content_id = $_GET['content_id'];

    if(delete_all_quiz_answers($quiz_id) && delete_all_quiz_question($quiz_id))
    {
        if(delete_quiz($quiz_id))
        {
            header("Location: content_view.php?content_id=".$_GET['content_id']);
            echo "<script>alert('".$_GET['content_id']."');</script>";
            echo "<script>alert('Quiz Deleted Successfully!');</script>";
        }
        else
        {
            echo "<script>alert('Error Deleting Quiz!');</script>";
        }
        
    }
    else
    {
        echo "<script>alert('Error Deleting Quiz!');</script>";
    }

    function delete_all_quiz_answers($quiz_id)
    {
        global $connect;
        $sql = "DELETE FROM `quiz_answer` WHERE `associated_quiz_id` = '$quiz_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            return true;
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

    function delete_all_quiz_question($quiz_id)
    {
        global $connect;
        $sql = "DELETE FROM `quiz_question` WHERE `associated_quiz_id` = '$quiz_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            return true;
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

    function delete_quiz($quiz_id)
    {
        global $connect;
        $sql = "DELETE FROM `course_content_quiz` WHERE `quiz_id` = '$quiz_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            return true;
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

?>