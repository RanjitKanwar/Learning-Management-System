var elements = document.getElementsByClassName("column");

var i;

// var listView = document.getElementById("list-view");
// listView.onclick = function() {
//     listView();
// }; 

// var gridView = document.getElementById("grid-view");
// listView.onclick = function() {
//     gridView();
// }; 

function listView() {
    console.log("clicked list view");
  for (i = 0; i < elements.length; i++) {
    elements[i].style.width = "100%";
  }
}

function gridView() {
    console.log("clicked grid view");
  for (i = 0; i < elements.length; i++) {
    elements[i].style.width = "30%";
  }
}