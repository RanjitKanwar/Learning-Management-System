<?php

    session_start();

    if(!isset($_SESSION['teacher_id']))
    {
        header("Location: ../common/index.php");
    }
    include_once('../config/db_connect.php');
    $connect = connect_to_db($server_name, $user_name, $password, $db_name);

    if(!$connect){
        echo "Connection failed: ".mysqli_connect_error();
    }

    if(!isset($_GET['quiz_id']) && !isset($_GET['question_no']))
    {
        header("Location: course_view.php");
    }

    $quiz_id = $_GET['quiz_id'];
    $question_number = $_GET['question_no'];

    function get_quiz_questions($quiz_id)
    {
        global $connect;
        $sql = "SELECT * FROM `quiz_question` WHERE `associated_quiz_id` = '$quiz_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                return $result;
            }
            else
            {
                echo "<h2>No Quiz Found!</h2>";
            }  
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

    function get_quiz_all_answer_option($question_id, $quiz_id)
    {
        global $connect;
        $sql = "SELECT * FROM `quiz_answer` WHERE `associated_with_question` = '$question_id' AND `associated_quiz_id` = '$quiz_id'";
        $result = mysqli_query($connect, $sql);
        if($result)
        {
            if(mysqli_num_rows($result) > 0)
            {
                return $result;
            }
            else
            {
                echo "<h2>No Quiz Found!</h2>";
            }  
        }
        else
        {
            echo "Error: ".mysqli_error($connect);
        }
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>LMS - View Quiz</title>
        <link type="stylesheet" href="../styles/common_layout.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <link rel="stylesheet" href="../styles/styles.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-custom navbar-expand-md">
        <a class="navbar-brand" href="#"><h5>Quiz</h5></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" style="color:white" href="index.php">Go Back To Dashboard</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
        <div class="container">
        <div class="p-2">
        <h1>Quiz</h1>
        <table class="table">
            <tr>
                <th>Quiz Question</th>
            </tr>
            <tr>
                <td>
                    <?php
                        
                        $quiz_questions = get_quiz_questions($quiz_id);
                        $all_ques = array();
                        while($row = mysqli_fetch_assoc($quiz_questions))
                        {
                            $all_ques[] = $row;
                        }
                        if($question_number >= count($all_ques))
                        {
                            $question_number = count($all_ques) - 1;
                        }
                        else if($question_number <= 0)
                        {
                            $question_number = 0;
                        }
                        echo $all_ques[$question_number]['question_text'];
                        $quiz_answers = get_quiz_all_answer_option($all_ques[$question_number]['question_id'], $quiz_id);
                        $all_answer_option = array();
                        $count = 0;
                        while($row = mysqli_fetch_assoc($quiz_answers))
                        {
                            $all_answer_option[] = $row;
                            if($row['is_correct_option'] == 1)
                            {
                                echo "<button class='btn btn-success' style='margin:7px'>".$row['option_text']."</button>  ";
                            }
                            else
                            {
                                echo "<button class='btn btn-secondary' style='margin:7px'>".$row['option_text']."</button>  ";
                            }
                            if($count % 2 == 1)
                            {
                                echo "<br>";
                            }
                        }
                        
                    ?>
                </td>
            </tr>
            <tr>
                <td><a class="btn btn-secondary" href="view_quiz_detail.php?quiz_id=<?php echo $quiz_id;?>&question_no=<?php echo $question_number-1;?>">Prev</a></td>
                <td><a class="btn btn-primary" href="view_quiz_detail.php?quiz_id=<?php echo $quiz_id;?>&question_no=<?php echo $question_number+1;?>">Next</a></td>
            </tr>
        </table>
        </div>
        </div>
    </body>
</html>