<?php
    
        include '../config/db_config.php';
        
        function connect_to_db($server_name, $user_name, $password, $db_name) {
            $connect = mysqli_connect($server_name, $user_name, $password, $db_name);
            
            if (!$connect) {
                die("Connection failed: ".mysqli_connect_error());
            }
            else
            {
                return $connect;
            }

        }
        

?>